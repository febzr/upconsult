<!DOCTYPE html>
<html lang="PT-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upconsult</title>

    <!--
        FONTES:
            font-family: 'Inter', sans-serif;
            font-family: 'Montserrat', sans-serif;
        CORES PRINCIPAIS:
            azul: #121276
            amarelo: #E5C73F
            cinza claro: #D9D9D9
            cinza escuro: #1E1E26
            verde: #0B9F08
    -->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <link rel="icon" type="image/png" href="./Resources/Plataforma/geral-logo-amarela.png">
    <link rel="stylesheet" href="upconsult_index_style.css">
</head>

<body>

    <!-- Menu principal -->
    <header class="menu-principal">
        <figure class="imagem-logo">
            <img src="./Resources/Plataforma/geral-logo-amarela.png" alt="">
        </figure>
        <nav id="menu-opcoes">
            <ul>
                <li class="icone-menu mensagens"><a href="">
                        <img src="./Resources/Plataforma/geral-menu-mensagens.png" alt="">
                    </a></li>
                <li class="icone-menu agenda"><a href="">
                        <img src="./Resources/Plataforma/geral-menu-agenda.png" alt="">
                    </a></li>
                <li class="icone-menu notificacoes"><a href="">
                        <img src="./Resources/Plataforma/geral-menu-notificacoes.png" alt="">
                    </a></li>
                <li class="icone-menu-config"><a href="">
                        <img src="./Resources/Plataforma/geral-menu-configs.png" alt="">
                    </a></li>
            </ul>
        </nav>
    </header>


    <!-- Parte principal do consultor -->
    <main class="principal-consultor">
        <section class="info-principais">
            <div class="info-principais-card">
                <figure class="info-principais-foto-perfil">
                    <img src="./Resources/Plataforma/geral-foto-perfil-three.png" alt=""
                        id="info-principais-foto-consultor">
                </figure>
                <div>
                    <p class="info-principais-nome-consultor"><strong>Empresa do consultor</strong></p>
                    <p class="info-principais-localizacao-consultor">Localização da empresa</p>
                </div>
            </div>
            <div class="info-principais-card-atendimento-consultor">
                <img src="./Resources/Plataforma/geral-atendimento.png" alt="">
            </div>
            <div class="info-principais-criar-feed-consultor">
                <img src="./Resources/Plataforma/consultor-criar-feed.png" alt="">
            </div>
        </section>
        <section class="feed-comunidade-consultor">
            <div class="fed">
                <h2>Feed</h2>
            </div>
            <div class="feed-card-consultor">
                <div class="card-feed-info-empresa">
                    <img src="./Resources/Plataforma/geral-foto-perfil-two.png" alt="">
                </div>
                <div class="feed-info-empresa">
                    <p><strong>Nome da empresa</strong></p>
                    <p>Olinda-PE</p>
                </div>
                <div class="feed-solicitacao-empresa-consultor">
                    <div class="feed-foto-solicitacao-empresa">
                        <img src="./Resources/Plataforma/geral-imagem-empresa.png" alt="">
                    </div>
                    <div class="descricao-empresa">
                        <p><strong>Precisamos de ajuda!</strong></p><br>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                            ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                            ullamco</p>
                    </div>
                </div>
                <div class="feed-botoes-consultor">
                    <button class="feed-botao-responder-consultor">Responder</button>
                    <button class="feed-botao-ignorar-consultor">Ignorar</button>
                </div>
            </div>
            <div class="comunidade">
                <h2>Comunidade</h2>
                <div class="comunidade-card">
                    <div class="comunidade-card-perfil-consultor">
                        <figure class="comunidade-foto-consultor">
                            <img src="" alt="">
                        </figure>
                        <div class="comunidade-card-info-consultor">
                            <p><strong>Nome do consultor</strong></p>
                            <p>Rio de Janeiro - RJ</p>
                        </div>
                    </div>
                    <div class="comunidade-card-case">
                        <div class="comunidade-card-case-descricao">
                            <p><strong>Olá, comunidade, tenho um case grande que precisa de mais
                                um consultor para ajudar.</strong></p><br>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                ullamco</p>
                        </div>
                        <button class="comunidade-card-botao-parceria">Aceitar parceria</button>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Parte principal da empresa -->
    <main class="principal-empresa" style="display: none;">
        <section class="info-principais">

        </section>
        <section class="feed-comunidade">
            <div class="feed">
                <h2>Feed</h2>
                <div class="feed-card">

                </div>
            </div>
            <div class="comunidade">
                <h2>Comunidade</h2>
                <div class="comunidade-card">

                </div>
            </div>
        </section>

    </main>

    <!--Atendimento Consultor-->
    <main class="atendimento-consultor" style="display:none;">

    </main>

    <!--Atendimento Empresa-->
    <main class="atendimento-empresa" style="display:none;">

    </main>

    <!-- Área de notificações consultor -->
    <aside class="forms-mensagens-consultor">
        <!-- Form de proposta de solução -->
        <div class="form-proposta-cosultor">
            <h2>Proposta de solução</h2>
            <div class="card-solicitacao">
                <div>
                    <figure>
                        <img src="./Resources/Plataforma/geral-foto-perfil-two.png" alt=""
                            class="proposta-foto-usuario-empresa">
                    </figure>
                    <div>
                        <p class="proposta-nome-empresa">Nome da empresa</p>
                        <p class="proposta-area-consultoria" style="display:none"></p>
                        <p class="proposta-cidade-empresa">Cidade da empresa</p>
                    </div>
                </div>
                <div>
                    <p class="proposta-titulo">Precisamos de ajuda! Vendas despencando!</p>
                    <p class="proposta-descricao-empresa">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                        do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                        nostrud exercitation ullamco</p>
                </div>
            </div>
            <form action="/plataformaConsultor/agendamento" method="post" class="form" id="proposta-consultor">
                <label for="descricaoSolucao">Descrição da solução</label><br>
                <textarea name="descricaoSolucao" id="descricaoSolucao" cols="30" rows="10" placeholder="Escreva aqui"
                    required></textarea><br>
                <label for="dataAtendimentoConsultor">Sugestão de data para atendimento</label><br>
                <input type="date" id="dataAtendimentoConsultor" name="dataAtendimentoConsultor" required><br>
                <label for="horaAtendimentoConsultor">Sugestão de hora para atendimento</label><br>
                <input type="time" id="horaAtendimentoConsultor" name="horaAtendimentoConsultor" required><br>
                <input type="submit" value="Enviar proposta de solução"><br>
            </form>
        </div>

        <!-- Agenda consultor -->
        <div class="agenda-consultor">
            <h2>Agenda</h2>
            <div class="card-agenda-consultor">
                <figure>
                    <img src="./Resources/Plataforma/geral-foto-perfil-two.png" alt=""
                        class="agenda-foto-usuario-empresa">
                </figure>
                <div>
                    <p class="agenda-nome-empresa">Nome da empresa</p>
                    <p class="agenda-data-atendimento">Horário do atendimento 00:00</p>
                </div>
                <div>
                    <img src="./Resources/Plataforma/geral-agenda-texto.png" alt=""
                        class="agenda-consultor-icone-mensagem">
                    <img src="./Resources/Plataforma/geral-agenda-ligacao.png" alt=""
                        class="agenda-consultor-icone-ligacao">
                    <img src="./Resources/Plataforma/geral-agenda-cancelamento.png" alt=""
                        class="agenda-consultor-icone-cancelamento">
                </div>
            </div>
        </div>

        <!-- Área de mensagens em tempo real -->
        <div class="mensagens-live-consultor" style="display:none">
            <h2>Mensagens da chamada</h2>
            <div class="mensagens-consultor">

            </div>
        </div>

        <!--Área de feedbacks recebidos-->
        <div class="feedbacks-notificacoes-consultor">
            <h2>Notificações</h2>
            <div class="feedback-consultor">
                <div>
                    <figure>
                        <img src="Resources/Plataforma/geral-foto-perfil-one.png" alt=""
                            class="feedback-consultor-imagem-empresa">
                    </figure>
                </div>
                <div>
                    <p class="feedback-consultor-nome-empresa">Nome da empresa</p>
                    <p class="feedback-consultor-cidade-empresa">Cidade da empresa</p>
                </div>
                <div>
                    <p class="feedback-consultor-titulo">Obrigado por nos ajudar!</p>
                    <p class="feedback-consultor-descricao">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                        do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                        nostrud exercitation ullamco</p>
                    <button class="feedback-consultor-botao-publicar">Publicar Feedback</button>
                </div>
            </div>
        </div>
    </aside>

    <!-- Área de notificações empresa -->

    <aside class="forms-mensagens-empresa" style="display:none;">
        <!--Form de solicitação de consultoria-->
        <div class="form-empresa-solicitacao-consultoria">
            <h2>Solicitação de consultoria</h2>
            <form action="">
                <label for="titulo-solicitacao-empresa">Título da solicitação</label><br>
                <input type="text" name="titulo-solicitacao-empresa" id="titulosolicitacaoempresa" required><br>
                <label for="descricao-solicitacao-empresa">Descrição de solicitação</label><br>
                <textarea name="descricao-solicitacao-empresa" id="descricaosolicitacaoempresa" cols="30" rows="10"
                    placeholder="Escreva aqui" required></textarea><br>
                <label for="area-de-consultoria-empresa">Área de consutolria</label><br>
                <select name="area-de-consultoria-empresa" id="areadeconsultoriaempresa" required>
                    <option value="vendas">Vendas</option>
                    <option value="gestao">Gestão</option>
                    <option value="finanças">Finanças</option>
                    <option value="MKT">Marketing</option>
                    <option value="RH">Recursos Humanos</option>
                    <option value="TI">Tecnologia da informação</option>
                    <option value="sustentabilidade">Sustentabilidade</option>
                </select><br>
                <input type="submit" name="enviar-solicitacao" id="enviarsolicitacao"
                    value="Enviar solicitação de consultoria"><br>
            </form>
        </div>
        <!-- mensagens da empresa -->
        <div class="mensagem-resposta-solicitacao-empresa">
            <div class="resposta-resumo-solicitacao">
                <div class="foto-empresa-solicitacao">
                    <figure>
                        <img src="" alt="">
                    </figure>
                    <div class="info-empresa-solicitacao">
                        <p></p>
                        <p></p>
                    </div>
                </div>
                <div class="mensagem-descricao-solicitacao">
                    <p></p>
                    <p></p>
                </div>
                <div class="card-resposta-consultor">
                    <div class="info-consultor-resposta">
                        <figure class="foto-consultor-solicitacao">
                            <img src="" alt="">
                        </figure>
                        <div class="info-consultor-solicitacao">
                            <p></p>
                            <p></p>
                        </div>
                    </div>
                    <div class="mensagem-resposta-solicitacao">
                        <p></p>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="botoes-mensagem-empresa">
                <button class="aceitar-empresa">Aceitar Proposta</button>
                <button class="analisar-empresa">Recusar/Analisar</button>
            </div>
        </div>

        <!--Agenda consultoria empresa-->
        <div class="agenda-empresa">
            <h2>Agenda</h2>
            <div class="card-agenda-empresa">
                <figure>
                    <img src="" alt="" class="agenda-foto-usuario-consultor">
                </figure>
                <div>
                    <p class="agenda-nome-consultor"></p>
                    <p class="agenda-data-atendimento-empresa"></p>
                </div>
                <div>
                    <img src="" alt="" class="agenda-empresa-icone-mensagem">
                    <img src="" alt="" class="agenda-empresa-icone-ligacao">
                    <img src="" alt="" class="agenda-empresa-icone-cancelamento">
                </div>
            </div>
        </div>

        <!--Formulário de feedback-->
        <div class="form-feedback-empresa">
            <div>
                <figure>
                    <img src="" alt="">
                </figure>
                <div>
                    <p></p>
                    <p></p>
                </div>
            </div>
            <form action="" id="form-empresa-feedback">
                <label for="titulo-feedback">Título do feedback</label><br>
                <input type="text" name="titulo-feedback" id="titulofeedback" required><br>
                <label for="descricao-feedback">Descreva a experiência</label><br>
                <textarea name="descricao-feedback" id="descricaofeedback" cols="30" rows="10"
                    placeholder="Escreva aqui" required></textarea><br>
                <label for="classificacao-consultoria-empresa">Como você classifica a consultoria?</label><br>
                <select name="classificacao-consultoria-empresa" id="classificacaoconsultoriaempresa" required>
                    <option value="ruim">Ruim</option>
                    <option value="regular">Regular</option>
                    <option value="bom">Bom</option>
                    <option value="otimo">Ótimo</option>
                    <option value="excelente">Excelente/exemplar</option>
                </select><br>
                <input type="submit" value="Enviar feedback"><br>
            </form>
        </div>
    </aside>
    <script src="./upconsult-script.js" type="js"></script>
</body>

</html>
